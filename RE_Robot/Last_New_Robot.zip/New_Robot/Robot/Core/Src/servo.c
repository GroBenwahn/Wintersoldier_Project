#include "servo.h"
#include "can_comm.h"
#include "switch_mode.h"

/* Waist 이동 속도: ServoTask 1회(20ms)당 1도 이동 = 50도/초 */
#define WAIST_STEP  1

/* Shoulder(Flex3) 실측 굽힘 범위 → 90~0도 리매핑 기준값 (방향 반전: MIN→90, MAX→0) */
#define FLEX3_MIN 1670
#define FLEX3_MAX 1857

/* Shoulder 이동 속도: SHOULDER_STEP_INTERVAL회(20ms)마다 1도 이동 (간격 늘리면 더 느려짐) */
#define SHOULDER_STEP           1
#define SHOULDER_STEP_INTERVAL  2   /* 40ms당 1도 = 25도/초 */

/* Wrist Roll/Pitch 실측 범위 (0=중립 기준, 더 큰 쪽 크기로 스케일) */
#define ROLL_SCALE   900   /* 위 +900, 아래 -900 */
#define PITCH_SCALE  900   /* 오른쪽 +900, 왼쪽 -800 (900 기준, 왼쪽은 -90까지 안 닿고 -80까지만 감) */

/* Wrist Pitch(Roll 구동) 이동 속도: 40ms마다 3도 */
#define WRIST_STEP                3
#define WRIST_STEP_INTERVAL       2

/* Wrist Roll(Pitch 구동, 좌우 트는 동작이라 떨림이 심해 더 느리게) */
#define WRIST_ROLL_STEP_INTERVAL  4   /* 80ms마다 3도 */

/* 현재 서보 출력 각도 (-90~+90도), LcdTask에서 읽음 */
int8_t servo_angles[6] = {0};

/* Waist 현재 누적 위치 */
static int8_t waist_pos = 0;

/* Shoulder 현재 누적 위치 (급격한 점프 방지용) */
static int8_t shoulder_pos = 0;
static uint8_t shoulder_tick = 0;

/* Wrist Roll/Pitch 현재 누적 위치 (급격한 점프 방지용) */
static int8_t wrist_roll_pos  = 0;
static int8_t wrist_pitch_pos = 0;
static uint8_t wrist_roll_tick  = 0;
static uint8_t wrist_pitch_tick = 0;

/* G센서 roll/pitch 저역통과 필터 값 (raw 노이즈 완화, 1/16씩 반영) */
static int16_t roll_filtered  = 0;
static int16_t pitch_filtered = 0;


/* 각도(-90~+90) → PWM CCR 변환 (PSC=169, ARR=19999 기준, 1μs/tick) */
static uint32_t angle_to_ccr(int8_t angle)
{
    int32_t ccr = 1500 + (int32_t)angle * 1000 / 90;
    if (ccr < 500)  ccr = 500;
    if (ccr > 2500) ccr = 2500;
    return (uint32_t)ccr;
}


/* int32_t → int8_t 클램프 */
static int8_t clamp8(int32_t val, int8_t min_val, int8_t max_val)
{
    if (val < min_val) return min_val;
    if (val > max_val) return max_val;
    return (int8_t)val;
}


/* TIM 채널에 각도 출력 */
static void SetPWM(TIM_HandleTypeDef *htim, uint32_t channel, int8_t angle)
{
    __HAL_TIM_SET_COMPARE(htim, channel, angle_to_ccr(angle));
}


/* PWM 6채널 시작 + 전체 서보 중립(0도) 초기화 */
void Servo_Init(void)
{
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);   /* Waist       */
    HAL_TIM_PWM_Start(&htim17, TIM_CHANNEL_1);  /* Shoulder    */
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);   /* Elbow       */
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);   /* Wrist Roll  */
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);   /* Wrist Pitch */
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);   /* Grip        */

    SetPWM(&htim3, TIM_CHANNEL_2, 0);
    SetPWM(&htim17, TIM_CHANNEL_1, 0);
    SetPWM(&htim3, TIM_CHANNEL_3, 0);
    SetPWM(&htim1, TIM_CHANNEL_1, 0);
    SetPWM(&htim1, TIM_CHANNEL_2, 0);
    SetPWM(&htim2, TIM_CHANNEL_1, 0);
}


/*
 * 패킷 → 서보 각도 계산 → PWM 출력 (ServoTask에서 20ms마다 호출)
 *
 * comm_mode에 따라 데이터 출처가 다름:
 *  - COMM_CAN: latest_can_gsensor/latest_can_flex (Gsensor_t/Flex_t, CAN 전용)
 *  - 그 외(COMM_BT 등): latest_gPkt/latest_fPkt (GSensorPacket_t/FlexPacket_t, BT 전용)
 */
void Servo_Update(void)
{
    int16_t  roll, pitch;
    uint8_t  height_sw;
    uint16_t flex1, flex2, flex3;

    if (SwitchMode_Get() == COMM_CAN)
    {
        roll      = latest_can_gsensor.BIT_FIELD.roll;
        pitch     = latest_can_gsensor.BIT_FIELD.pitch;
        height_sw = latest_can_gsensor.BIT_FIELD.height_sw;
        flex1     = latest_can_flex.BIT_FIELD.flex1;
        flex2     = latest_can_flex.BIT_FIELD.flex2;
        flex3     = latest_can_flex.BIT_FIELD.flex3;
    }
    else
    {
        roll      = latest_gPkt.roll;
        pitch     = latest_gPkt.pitch;
        height_sw = latest_gPkt.height_sw;
        flex1     = latest_fPkt.flex1;
        flex2     = latest_fPkt.flex2;
        flex3     = latest_fPkt.flex3;
    }

    /* ── Waist: Switch Up/Down으로 누적 이동 ── */
    switch ((HeightSwitch_t)height_sw)
    {
        case HEIGHT_UP:
            if (waist_pos < 90) waist_pos += WAIST_STEP;
            break;
        case HEIGHT_DOWN:
            if (waist_pos > -90) waist_pos -= WAIST_STEP;
            break;
        default:
            break;
    }
    servo_angles[SERVO_WAIST] = waist_pos;
    SetPWM(&htim3, TIM_CHANNEL_2, waist_pos);

    /* ── Shoulder: Flex 3 (실측 범위 1670~1857 → 90~0도로 보정, 방향 반전) ── */
    int8_t shoulder_target = clamp8((FLEX3_MAX - (int32_t)flex3) * 90 / (FLEX3_MAX - FLEX3_MIN), 0, 90);
    shoulder_tick++;
    if (shoulder_tick >= SHOULDER_STEP_INTERVAL)
    {
        shoulder_tick = 0;
        int8_t shoulder_diff = shoulder_target - shoulder_pos;
        if (shoulder_diff > SHOULDER_STEP)       shoulder_pos += SHOULDER_STEP;
        else if (shoulder_diff < -SHOULDER_STEP) shoulder_pos -= SHOULDER_STEP;
        else                                     shoulder_pos = shoulder_target;
    }
    servo_angles[SERVO_SHOULDER] = shoulder_pos;
    SetPWM(&htim17, TIM_CHANNEL_1, shoulder_pos);

    /* ── Elbow: Flex 2 (0~4095 → 0~+90도) ── */
    int8_t elbow = clamp8((int32_t)flex2 * 90 / 4095, 0, 90);
    servo_angles[SERVO_ELBOW] = elbow;
    SetPWM(&htim3, TIM_CHANNEL_3, elbow);

    /* G센서 roll/pitch 저역통과 필터 (튀는 값을 미리 완만하게, pitch는 좌우 트는 동작 떨림이 심해 더 강하게) */
    roll_filtered  += ((int32_t)roll  - roll_filtered)  / 16;
    pitch_filtered += ((int32_t)pitch - pitch_filtered) / 32;

    /* ── Wrist Roll: G Pitch로 구동 (실측 -800~+900 → -90~+90도, 필터+서서히 이동) ── */
    int8_t wrist_roll_target = clamp8((int32_t)pitch_filtered * 90 / PITCH_SCALE, -90, 90);
    wrist_roll_tick++;
    if (wrist_roll_tick >= WRIST_ROLL_STEP_INTERVAL)
    {
        wrist_roll_tick = 0;
        int8_t diff = wrist_roll_target - wrist_roll_pos;
        if (diff > WRIST_STEP)       wrist_roll_pos += WRIST_STEP;
        else if (diff < -WRIST_STEP) wrist_roll_pos -= WRIST_STEP;
        else                         wrist_roll_pos = wrist_roll_target;
    }
    servo_angles[SERVO_WRIST_ROLL] = wrist_roll_pos;
    SetPWM(&htim1, TIM_CHANNEL_1, wrist_roll_pos);

    /* ── Wrist Pitch: G Roll로 구동 (실측 -900~+900 → -90~+90도, 필터+서서히 이동) ── */
    int8_t wrist_pitch_target = clamp8((int32_t)roll_filtered * 90 / ROLL_SCALE, -90, 90);
    wrist_pitch_tick++;
    if (wrist_pitch_tick >= WRIST_STEP_INTERVAL)
    {
        wrist_pitch_tick = 0;
        int8_t diff = wrist_pitch_target - wrist_pitch_pos;
        if (diff > WRIST_STEP)       wrist_pitch_pos += WRIST_STEP;
        else if (diff < -WRIST_STEP) wrist_pitch_pos -= WRIST_STEP;
        else                         wrist_pitch_pos = wrist_pitch_target;
    }
    servo_angles[SERVO_WRIST_PITCH] = wrist_pitch_pos;
    SetPWM(&htim1, TIM_CHANNEL_2, wrist_pitch_pos);

    /* ── Grip: Flex 1 (0~4095 → 0~+90도) ── */
    int8_t grip = clamp8((int32_t)flex1 * 90 / 4095, 0, 90);
    servo_angles[SERVO_GRIP] = grip;
    SetPWM(&htim2, TIM_CHANNEL_1, grip);
}
