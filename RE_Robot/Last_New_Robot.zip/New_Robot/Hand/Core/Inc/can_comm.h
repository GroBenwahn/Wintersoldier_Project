#ifndef __CAN_COMM_H
#define __CAN_COMM_H

#include "Packet.h"
#include "main.h"

/* HAL 핸들 (main.c에서 선언) */
extern FDCAN_HandleTypeDef hfdcan1;

/* CAN 연결 상태 */
extern uint8_t can_offline;

/* 함수 선언 */
void CAN_Comm_Init(void);
void CAN_Send(uint32_t id);   /* id에 맞는 전역 패킷(gsensor_data/flex_data/hand_status_data, Packet.h)을 그대로 송신 */
void CAN_Recovery(void);

#endif /* __CAN_COMM_H */
