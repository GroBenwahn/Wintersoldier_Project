#include "can_comm.h"

#define CAN_RECOVERY_INTERVAL_MS  2000

/* CAN 연결 상태 (0=온라인, 1=오프라인) */
uint8_t can_offline = 0;
static uint32_t can_retry_tick = 0;

/* CAN으로 송신할 패킷 전역 버퍼 (main.c의 Callback_100ms가 값을 채운 뒤 CAN_Send(id) 호출) */
Gsensor_t    gsensor_data     = {0};
Flex_t       flex_data        = {0};
HandStatus_t hand_status_data = {0};


/* 공통 TX 헤더 생성 (Identifier만 다르고 나머지는 고정) */
static FDCAN_TxHeaderTypeDef CAN_MakeTxHeader(uint32_t id)
{
    FDCAN_TxHeaderTypeDef header = {
        .Identifier          = id,
        .IdType              = FDCAN_STANDARD_ID,
        .TxFrameType         = FDCAN_DATA_FRAME,
        .DataLength          = FDCAN_DLC_BYTES_8,
        .ErrorStateIndicator = FDCAN_ESI_ACTIVE,
        .BitRateSwitch       = FDCAN_BRS_OFF,
        .FDFormat            = FDCAN_CLASSIC_CAN,
        .TxEventFifoControl  = FDCAN_NO_TX_EVENTS,
        .MessageMarker       = 0,
    };
    return header;
}


/* CAN 초기화: Bus-Off 알림 등록 + 시작 */
void CAN_Comm_Init(void)
{
    HAL_FDCAN_ActivateNotification(&hfdcan1, FDCAN_IT_BUS_OFF, 0);
    HAL_FDCAN_Start(&hfdcan1);
}


/*
 * ID별 CAN 송신 - id에 대응하는 전역 패킷(gsensor_data/flex_data/hand_status_data)의
 * BYTE_FIELD를 그대로 큐에 넣는다. 호출 전 해당 전역 버퍼에 값 + checksum을 먼저 채워둬야 함.
 *
 * 송신 직후 상태를 폴링해서 에러를 잡던 이전 방식은 타이밍이 안 맞아 신뢰할 수 없었음
 * (AddMessageToTxFifoQ는 큐에 넣기만 할 뿐, 실제 버스 전송/ACK 확인은 하드웨어에서
 * 비동기로 나중에 일어남). Bus-Off는 하드웨어 인터럽트(HAL_FDCAN_ErrorStatusCallback)로만
 * 감지한다 - 정확한 시점에 하드웨어가 알아서 알려주므로 타이밍 문제가 없음.
 */
void CAN_Send(uint32_t id)
{
    if (can_offline) return;

    FDCAN_TxHeaderTypeDef tx_header = CAN_MakeTxHeader(id);

    switch (id)
    {
        case CAN_MSG_SENSOR:
            HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &tx_header, gsensor_data.BYTE_FIELD);
            break;

        case CAN_MSG_FLEX:
            HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &tx_header, flex_data.BYTE_FIELD);
            break;

        case CAN_MSG_ERROR_HAND:
            HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &tx_header, hand_status_data.BYTE_FIELD);
            break;

        default:
            /* 정의되지 않은 ID, 무시 */
            break;
    }
}


/* 2초마다 CAN 복구 시도 (재시작만 하고 바로 온라인 전환 - 여전히 문제 있으면 Bus-Off 콜백이 다시 잡음) */
void CAN_Recovery(void)
{
    if (!can_offline) return;

    if ((HAL_GetTick() - can_retry_tick) < CAN_RECOVERY_INTERVAL_MS) return;
    can_retry_tick = HAL_GetTick();

    HAL_FDCAN_Start(&hfdcan1);
    can_offline = 0;
}


/* Bus-Off 인터럽트 콜백: 하드웨어가 TEC/REC 임계치를 넘었다고 판단한 정확한 시점에 호출됨 */
void HAL_FDCAN_ErrorStatusCallback(FDCAN_HandleTypeDef *hfdcan, uint32_t ErrorStatusITs)
{
    if (ErrorStatusITs & FDCAN_IT_BUS_OFF)
    {
        HAL_FDCAN_Stop(hfdcan);
        can_offline = 1;
    }
}
