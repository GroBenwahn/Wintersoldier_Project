#ifndef __PACKET_H
#define __PACKET_H

#include <stdint.h>

/* UART 프레임 마커 (BT용) */
#define PKT_START              0xAA
#define PKT_END                0x55

/* CAN 메시지 ID (0x100~0x102: Hand → Robot, 전부 100ms 주기 송신) */
#define CAN_MSG_SENSOR      0x100  /* Hand → Robot: G센서 + 높낮이 스위치 */
#define CAN_MSG_FLEX        0x101  /* Hand → Robot: Flex 센서 */
#define CAN_MSG_ERROR_HAND  0x102  /* Hand → Robot: 상태/에러 (내용 미정, 틀만 정의) */
#define CAN_MSG_SERVO_DBG   0x200  /* Robot → (디버그): 서보 6개 현재 각도 */
#define CAN_MSG_ERROR_ROBOT 0x201  /* Hand → Robot: 에러 발생 */


/* 높낮이 스위치 상태 (Up_Switch=PB4, Down_Switch=PB5, Active LOW) */
typedef enum
{
    HEIGHT_STOP = 0,   /* 둘다 HIGH → 정지 */
    HEIGHT_UP   = 1,   /* PB4=LOW  → 위로 */
    HEIGHT_DOWN = 2    /* PB5=LOW  → 아래로 */
} HeightSwitch_t;


/* =====================================================================
 * BT 전용 패킷 (건드리지 않음 - sensor.c/bluetooth.c에서 그대로 사용)
 *
 * UART 송신: [PKT_START(1)] [GSensorPacket_t(8)] [PKT_END(1)] = 10바이트
 * ===================================================================== */
#pragma pack(1)
typedef struct
{
    int16_t  roll;        /* ADXL345 Roll  각도, 단위 0.1도, -1800 ~ +1800 */
    int16_t  pitch;       /* ADXL345 Pitch 각도, 단위 0.1도, -1800 ~ +1800 */
    uint8_t  height_sw;   /* HeightSwitch_t (HEIGHT_STOP / HEIGHT_UP / HEIGHT_DOWN) */
    uint8_t  reserved[2]; /* 예약 (0으로 채움) */
    uint8_t  checksum;    /* XOR(byte 0 ~ 6) */
} GSensorPacket_t;        /* 총 8바이트 */
#pragma pack()

#pragma pack(1)
typedef struct
{
    uint16_t flex1;       /* Flex 센서 1, ADC 12bit값 (0 ~ 4095) */
    uint16_t flex2;       /* Flex 센서 2, ADC 12bit값 (0 ~ 4095) */
    uint16_t flex3;       /* Flex 센서 3, ADC 12bit값 (0 ~ 4095) */
    uint8_t  reserved[1]; /* 예약 (0으로 채움) */
    uint8_t  checksum;    /* XOR(byte 0 ~ 6) */
} FlexPacket_t;           /* 총 8바이트 */
#pragma pack()


/* =====================================================================
 * CAN 전용 패킷 (CAN ID: 0x100, 0x101, 0x102)
 *
 * union으로 감싸서 BYTE_FIELD(원시 8바이트)/BIT_FIELD(필드명) 양쪽으로 접근 가능.
 * 필드가 전부 바이트 단위로 딱 떨어져서(:N 비트필드 불필요) 이식성 문제 없이
 * __attribute__((packed)) 구조체만으로 충분함.
 * ===================================================================== */

/* CAN ID 0x100 - G센서 + 높낮이 스위치 */
#pragma pack(1)
typedef union
{
    uint8_t BYTE_FIELD[8];
    struct __attribute__((packed))
    {
        int16_t  roll;        /* ADXL345 Roll  각도, 단위 0.1도, -1800 ~ +1800 */
        int16_t  pitch;       /* ADXL345 Pitch 각도, 단위 0.1도, -1800 ~ +1800 */
        uint8_t  height_sw;   /* HeightSwitch_t */
        uint8_t  reserved[2]; /* 예약 (0으로 채움) */
        uint8_t  checksum;    /* XOR(byte 0 ~ 6) */
    } BIT_FIELD;
} Gsensor_t;              /* 총 8바이트 */
#pragma pack()
extern Gsensor_t gsensor_data;    /* Hand: CAN_Send(CAN_MSG_SENSOR) 직전 값 채우는 전역 버퍼 */


/* CAN ID 0x101 - Flex 센서 */
#pragma pack(1)
typedef union
{
    uint8_t BYTE_FIELD[8];
    struct __attribute__((packed))
    {
        uint16_t flex1;       /* Flex 센서 1, ADC 12bit값 (0 ~ 4095) */
        uint16_t flex2;       /* Flex 센서 2, ADC 12bit값 (0 ~ 4095) */
        uint16_t flex3;       /* Flex 센서 3, ADC 12bit값 (0 ~ 4095) */
        uint8_t  reserved[1]; /* 예약 (0으로 채움) */
        uint8_t  checksum;    /* XOR(byte 0 ~ 6) */
    } BIT_FIELD;
} Flex_t;                 /* 총 8바이트 */
#pragma pack()
extern Flex_t flex_data;          /* Hand: CAN_Send(CAN_MSG_FLEX) 직전 값 채우는 전역 버퍼 */


/* CAN ID 0x102 - Hand 상태/에러 (내용 미정, 틀만 정의) */
#pragma pack(1)
typedef union
{
    uint8_t BYTE_FIELD[8];
    struct __attribute__((packed))
    {
        uint8_t  reserved[7]; /* 내용 미정 - 추후 정의 */
        uint8_t  checksum;    /* XOR(byte 0 ~ 6) */
    } BIT_FIELD;
} HandStatus_t;            /* 총 8바이트 */
#pragma pack()
extern HandStatus_t hand_status_data;


/*
 * 패킷 3 - 서보 디버그 피드백 (CAN ID: 0x200)
 * Robot → CAN 분석기 전용 (컨트롤러로는 전송 안 함) - 미사용, 손 안 댐
 */
#pragma pack(1)
typedef struct
{
    int8_t   servo1;     /* 서보 1 현재 각도 (-90 ~ +90도, 중립=0) */
    int8_t   servo2;     /* 서보 2 현재 각도 (-90 ~ +90도, 중립=0) */
    int8_t   servo3;     /* 서보 3 현재 각도 (-90 ~ +90도, 중립=0) */
    int8_t   servo4;     /* 서보 4 현재 각도 (-90 ~ +90도, 중립=0) */
    int8_t   servo5;     /* 서보 5 현재 각도 (-90 ~ +90도, 중립=0) */
    int8_t   servo6;     /* 서보 6 현재 각도 (-90 ~ +90도, 중립=0) */
    uint8_t  reserved;   /* 예약 (0으로 채움) */
    uint8_t  checksum;   /* XOR(byte 0 ~ 6) */
} ServoDbgPacket_t;      /* 총 8바이트 */
#pragma pack()


/* 패킷 크기 */
#define GSENSOR_PKT_SIZE   ((uint8_t)sizeof(GSensorPacket_t))   // 8
#define FLEX_PKT_SIZE      ((uint8_t)sizeof(FlexPacket_t))      // 8
#define SERVO_DBG_PKT_SIZE ((uint8_t)sizeof(ServoDbgPacket_t))  // 8


/* UART 전체 프레임 크기 = START(1) + DATA(8) + END(1) = 10 */
#define UART_FRAME_SIZE    (1 + 8 + 1)


/* 체크섬 계산 (byte 0~6 XOR) - GSensorPacket_t/FlexPacket_t/Gsensor_t/Flex_t/HandStatus_t 전부 공용 */
#define CALC_CHECKSUM(p)   ((uint8_t)( \
    ((uint8_t*)(p))[0] ^ ((uint8_t*)(p))[1] ^ \
    ((uint8_t*)(p))[2] ^ ((uint8_t*)(p))[3] ^ \
    ((uint8_t*)(p))[4] ^ ((uint8_t*)(p))[5] ^ \
    ((uint8_t*)(p))[6] ))

#endif /* __PACKET_H */
